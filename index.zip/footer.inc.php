<div class="footer">
            <h2>Мы изучили основы PHP!</h2>
        </div>