

<?php 
 $p = 'Приветствую Вас на моей страничке!';
?>

<?php 
 $name = 'Владимир';
 $surname = 'Дмитриев';
 $city = 'Истра';
 $age = 54;
?>


<?php
include 'main.php';
?>

